1. How to make?
   make
2. How to execute?
   ./lab3 [alpha value] [input.block name] [input.net name] [output name]
3. Output filename?
   [output name]